import setBreakpoint from './setBreakpoint.mjs';
import getBreakpoint from './getBreakpoint.mjs';

export default { setBreakpoint, getBreakpoint };
